from django.apps import AppConfig


class ForumConfig(AppConfig):
    name = 'Forum'
