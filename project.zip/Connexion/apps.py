from django.apps import AppConfig


class ConnexionConfig(AppConfig):
    name = 'Connexion'
