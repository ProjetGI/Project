from django.apps import AppConfig


class MediaConfig(AppConfig):
    name = 'Media'
